export type Roles =
  | "store"
  | "brand"
  | "member"
  | "association"
  | "wholesaler"
  | string;
