export const BASE_API = `${process.env.NEXT_PUBLIC_SERVER}/`;
export const BASE_API_ENDPOINT = `${BASE_API}api/`;
