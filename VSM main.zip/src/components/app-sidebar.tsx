"use client";

import * as React from "react";
import {
  BriefcaseBusinessIcon,
  CreditCard,
  MegaphoneIcon,
  SquareTerminal,
  UsersRoundIcon,
  WorkflowIcon,
} from "lucide-react";

import { NavMain } from "@/components/nav-main";
import { NavUser } from "@/components/nav-user";
import { TeamSwitcher } from "@/components/team-switcher";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@/components/ui/sidebar";
import { useGetOwnprofileQuery } from "@/redux/features/AuthApi";

// This is sample data.
const data = {
  user: {
    name: "Admin",
    email: "admin@email.com",
    avatar: "/image/vsm-logo.webp",
  },
  navMain: [
    {
      title: "Dashboard",
      url: "/admin/dashboard",
      icon: SquareTerminal,
      isActive: true,
      items: [
        {
          title: "Analytics",
          url: "/admin/dashboard",
        },
      ],
    },
    {
      title: "User Management",
      url: "/admin/users",
      icon: UsersRoundIcon,
      items: [
        {
          title: "Members",
          url: "/admin/users/members",
        },
        {
          title: "Stores",
          url: "/admin/users/stores",
        },
        {
          title: "Brands",
          url: "/admin/users/brands",
        },
        {
          title: "Wholesalers",
          url: "/admin/users/wholesalers",
        },
        {
          title: "Associations",
          url: "/admin/users/associations",
        },

        {
          title: "Suspensions & Bans",
          url: "/admin/users/suspensions-bans",
        },
      ],
    },
    {
      title: "Business Management",
      url: "/admin/business",
      icon: BriefcaseBusinessIcon,
      items: [
        {
          title: "Subscriptions & Billing",
          url: "/admin/business/subscriptions-billing",
        },
        {
          title: "Interaction Management",
          url: "/admin/business/interaction-management",
        },
      ],
    },
    {
      title: "Content Moderation",
      url: "/admin/moderation",
      icon: WorkflowIcon,
      items: [
        {
          title: "Home",
          url: "/admin/moderation/home",
        },
        {
          title: "Reviews",
          url: "/admin/moderation/reviews",
        },
        {
          title: "Edit Footer Content",
          url: "/admin/moderation/footercontent",
        },
        {
          title: "Manage Categories",
          url: "/admin/moderation/mangecategories",
        },
        {
          title: "Legal & Policies",
          url: "/admin/moderation/legal-policies",
        },
        {
          title: "Articles",
          url: "/admin/moderation/articles",
        },
        {
          title: "Violation Notices",
          url: "/admin/moderation/violation-notices",
        },
        {
          title: "Manage Regions",
          url: "/admin/moderation/region",
        },
      ],
    },
    {
      title: "Advertising",
      url: "/admin/advertising",
      icon: MegaphoneIcon,
      items: [
        {
          title: "Ad Approvals",
          url: "/admin/advertising/ad",
        },
        {
          title: "Most Hearted Ad Manager",
          url: "/admin/advertising/most-hearted-ad-manager",
        },
        {
          title: "Most followers Ad Manager",
          url: "/admin/advertising/most-followers-ad-manager",
        },
        {
          title: "Featured Ad Manager",
          url: "/admin/advertising/featured-ad-manager",
        },
      ],
    },
    {
      title: "Billing Management",
      url: "/admin/billing",
      icon: CreditCard,
      items: [
        {
          title: "Add Subscriptions",
          url: "/admin/billing/subscriptions",
        },
        {
          title: "Manage Subscriptions",
          url: "/admin/billing/subscribetions_mangement",
        },
        {
          title: "Orders and payments",
          url: "/admin/billing/orders",
        },
        {
          title: "Transaction Keys",
          url: "/admin/billing/keys",
        },
        {
          title: "B2B Transactions",
          url: "/admin/billing/b-to-b",
        },
      ],
    },
  ],
};

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { data: usrData } = useGetOwnprofileQuery();

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        <TeamSwitcher />
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
      </SidebarContent>
      <SidebarFooter>
        <NavUser
          user={{
            full_name: usrData?.data?.full_name,
            email: usrData?.data?.email,
            avatar: usrData?.data?.avatar,
          }}
        />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
