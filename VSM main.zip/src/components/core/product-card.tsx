"use client";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ProductType } from "@/lib/types/product";
import { Button } from "../ui/button";
import {
  CopyIcon,
  Edit2Icon,
  EllipsisVerticalIcon,
  HeartIcon,
  MailIcon,
  Share2Icon,
  Trash2Icon,
  WaypointsIcon,
} from "lucide-react";
import Link from "next/link";
import { useFevoriteUnveforiteMutation } from "@/redux/features/Trending/TrendingApi";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog";
import { useDeleteProdMutation } from "@/redux/features/manage/product";
import {
  EmailShareButton,
  FacebookShareButton,
  LinkedinShareButton,
  TwitterShareButton,
} from "react-share";
import { FaFacebook, FaLinkedin, FaTwitter } from "react-icons/fa";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useEffect, useState } from "react";
import { Input } from "../ui/input";
import { useGetOwnprofileQuery } from "@/redux/features/AuthApi";

export default function ProductCard({
  refetchAds,
  refetch,
  data,
  manage,
  link,
  role,
  blank,
  isBrand,
  hearted,
  noPrice,
  admin,
}: {
  refetchAds?: () => void;
  refetch?: () => void;
  data: ProductType;
  manage?: boolean;
  link?: string;
  role?: number;
  blank?: boolean;
  isBrand?: boolean;
  hearted?: boolean;
  noPrice?: boolean;
  admin?: boolean;
}) {
  const [copied, setCopied] = useState(false);
  const [currentUrl, setCurrentUrl] = useState("");

  // State to control modals preventing "ghost menu" bug
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);

  const { data: user } = useGetOwnprofileQuery();
  const userRole = user?.data?.role;

  useEffect(() => {
    if (typeof window !== "undefined") {
      const origin = window.location.origin;
      setCurrentUrl(`${origin}/stores/store/product/${data.id}`);
    }
  }, [data.id]);

  const [fevoriteUnveforite] = useFevoriteUnveforiteMutation();
  const [deleteProd, { isLoading }] = useDeleteProdMutation();

  const handleFebandUnfev = async (id: number) => {
    const alldata = {
      product_id: data?.id ?? id,
      role: role || 3,
    };
    try {
      const response = await fevoriteUnveforite(alldata).unwrap();

      if (response.ok) {
        // ✅ FIXED: Use optional chaining to call the function only if it exists
        refetchAds?.();
        refetch?.();

        toast.success(response.message || "Favorite successfully");
      }
    } catch (error: any) {
      toast.error(error?.data?.message || "Failed to Favorite");
    }
  };
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      toast.success("Link copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err: any) {
      toast.error(err?.data?.message || "Failed to copy link");
    }
  };

  return (
    <Card className="!p-0 !gap-0 shadow-sm overflow-hidden group relative">
      <div
        className="w-full aspect-square bg-center bg-no-repeat bg-cover rounded-t-lg relative transition-transform duration-300"
        style={{ backgroundImage: `url('${data.image}')` }}
      >
        {data.type === "ad" && (
          <div className="absolute top-4 left-4 text-2xl md:text-4xl">🔥</div>
        )}

        {!blank && (
          <div className="absolute bottom-2 right-2 flex z-50">
            <Button
              className="!text-sm"
              variant="outline"
              onClick={(e) => handleFebandUnfev(data?.id as number)}
            >
              {data?.hearts || 0}
              <HeartIcon
                className={`ml-1 size-5 ${data?.is_hearted || hearted ? "text-red-500 fill-red-500" : ""
                  }`}
              />
            </Button>
          </div>
        )}

        {manage && (
          <div className="absolute top-2 right-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="icon" variant="secondary">
                  <EllipsisVerticalIcon />
                </Button>
              </DropdownMenuTrigger>

              <DropdownMenuContent side="bottom" align="end">
                {!admin && (
                  <DropdownMenuItem asChild>
                    <Link href={`/me/manage/${data.id}`}>
                      <Edit2Icon className="mr-2 h-4 w-4" />
                      Edit
                    </Link>
                  </DropdownMenuItem>
                )}

                <DropdownMenuItem
                  variant="destructive"
                  onSelect={() => setIsDeleteOpen(true)}
                >
                  <Trash2Icon className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>

                <DropdownMenuItem onSelect={() => setIsShareOpen(true)}>
                  <Share2Icon className="mr-2 h-4 w-4" />
                  Share
                </DropdownMenuItem>

                {!admin && (
                  <DropdownMenuItem asChild>
                    <Link href={`/me/manage/b2b/${data.id}`}>
                      <WaypointsIcon className="mr-2 h-4 w-4" /> B2B
                    </Link>
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Modals are now outside the DropdownMenu to prevent UI bugs */}

            <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <Button
                    variant="destructive"
                    disabled={isLoading}
                    onClick={async () => {
                      try {
                        const res: any = await deleteProd({ id: data.id });
                        if (!res.ok) {
                          toast.error(res.message ?? "Failed to delete");
                        } else {
                          toast.success(
                            res.message ?? "Successfully deleted the product"
                          );
                          setIsDeleteOpen(false);
                        }
                      } catch (error) {
                        console.error(error);
                        toast.error("Something went wrong");
                      }
                    }}
                  >
                    {isLoading ? "Deleting..." : "Delete"}
                  </Button>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            <Dialog open={isShareOpen} onOpenChange={setIsShareOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Share this product</DialogTitle>
                </DialogHeader>
                <div className="flex items-center space-x-2">
                  <div className="grid flex-1 gap-2">
                    <Input value={currentUrl} readOnly />
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    className="px-3"
                    onClick={copyToClipboard}
                  >
                    <span className="sr-only">Copy</span>
                    <CopyIcon className="h-4 w-4" />
                  </Button>
                </div>
                <ShareButtons
                  url={currentUrl}
                  title={data?.title || "Check out this product"}
                />
              </DialogContent>
            </Dialog>
          </div>
        )}
      </div>

      {/* 🔹 Content - click to navigate */}
      <Link href={link ? link : "#"}>
        <div className="cursor-pointer">
          <CardContent className="!p-4 !space-y-1 transition-colors hover:text-primary">
            {data?.category && (
              <p className="text-muted-foreground font-bold text-sm md:text-base">
                {data.category}
              </p>
            )}

            <h3 className="lg:text-base font-semibold text-xs md:text-sm">
              {data.title}
            </h3>
            {data.thc_percentage && (
              <div className="text-sm text-muted-foreground">
                {data?.thc_percentage}% THC
              </div>
            )}
            {!noPrice &&
              userRole !== 6 &&
              (!data?.price || parseFloat(data.price) <= 0 ? (
                <div className="text-xs md:text-sm text-muted-foreground">
                  <span>Contact for pricing</span>
                </div>
              ) : (
                <div className="text-xs md:text-sm text-muted-foreground">
                  <span>${parseFloat(data.price)}</span>
                </div>
              ))}

            <div className="text-xs md:text-sm text-muted-foreground">
              {data?.note && <span>{data.note}</span>}
            </div>
          </CardContent>
        </div>
      </Link>

      {/* 🔹 Manage buttons */}
      {manage && !admin && (
        <CardFooter className="!p-4 grid grid-cols-2 gap-4">
          {isBrand && (
            <Button
              variant="special"
              asChild
              onClick={(e) => e.stopPropagation()}
            >
              <Link href={`/me/manage/ad-request?id=${data.id}`}>
                Ad request
              </Link>
            </Button>
          )}
          {link && (
            <Button
              variant="outline"
              className={!isBrand ? "col-span-2" : ""}
              asChild
              onClick={(e) => e.stopPropagation()}
            >
              <Link href={link}>View</Link>
            </Button>
          )}
        </CardFooter>
      )}
    </Card>
  );
}

interface ShareButtonsProps {
  url: string;
  title: string;
}
const ShareButtons: React.FC<ShareButtonsProps> = ({ url, title }) => {
  return (
    <div className="flex justify-center gap-4 pt-4">
      <FacebookShareButton url={url} hashtag="#vapeshopmaps">
        <Button variant="outline" size="icon" asChild>
          <FaFacebook className="h-5 w-5 text-blue-600" />
        </Button>
      </FacebookShareButton>
      <TwitterShareButton url={url} title={title}>
        <Button variant="outline" size="icon" asChild>
          <FaTwitter className="h-5 w-5 text-blue-400" />
        </Button>
      </TwitterShareButton>
      <LinkedinShareButton url={url} title={title}>
        <Button variant="outline" size="icon" asChild>
          <FaLinkedin className="h-5 w-5 text-blue-700" />
        </Button>
      </LinkedinShareButton>
      <EmailShareButton url={url} subject={title}>
        <Button variant="outline" size="icon" asChild>
          <MailIcon className="h-5 w-5 text-gray-600" />
        </Button>
      </EmailShareButton>
    </div>
  );
};