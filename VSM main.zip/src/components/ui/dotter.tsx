import React from "react";

export default function Dotter() {
  return <div className="size-2 rounded-full bg-muted-foreground" />;
}
