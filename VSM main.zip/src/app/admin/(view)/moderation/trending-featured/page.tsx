import TrendingSectionManager from "@/components/TrendingSectionManager";

import React from "react";

export default function Page() {
  return (
    <TrendingSectionManager title="Manage Trending sections" />
  );
}
