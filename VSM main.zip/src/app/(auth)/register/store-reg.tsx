"use client";

/* eslint-disable @typescript-eslint/no-explicit-any */
import type React from "react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Link from "next/link";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { useCountysQuery, useRegisterMutation } from "@/redux/features/AuthApi";
import { useRouter } from "next/navigation";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import MembershipInfo from "./membershipinfo";
import TermsModal from "@/components/PrivacyMOdal";

interface StoreRegisterFormData {
  store_name: string;
  email: string;
  phone: string;
  address: string;
  zip_code: string;
  region_id: string;
  password: string;
  password_confirmation: string;
  role: string;
  terms: boolean;
  ein: string;
}

interface Country {
  id: string;
  name: string;
}

export default function StoreRegister({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"div">) {
  const [register, { isLoading }] = useRegisterMutation();
  const { data: countriesResponse, isLoading: isLoadingCountries } =
    useCountysQuery();
  const router = useRouter();
  const [selectedCountryId, setSelectedCountryId] = useState<string>("");
  const [regions, setRegions] = useState<
    Array<{ id: number; name: string; code: string }>
  >([]);

  const {
    register: formRegister,
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
  } = useForm<StoreRegisterFormData>({
    defaultValues: {
      role: "5",
      region_id: "",
    },
  });

  const handleCountryChange = (countryId: string) => {
    setSelectedCountryId(countryId);
    const selectedCountry = countriesResponse?.data?.find(
      (c: { id: { toString: () => string } }) => c.id.toString() === countryId
    );
    setRegions(selectedCountry?.regions || []);
    setValue("region_id", ""); // Reset region when country changes
  };
  const [isModalOpen, setIsModalOpen] = useState(false);

  const onSubmit = async (data: StoreRegisterFormData) => {
    if (!data.terms) {
      toast.error("Please accept the terms and conditions");
      return;
    }

    if (!data.region_id) {
      toast.error("Please select a region");
      return;
    }

    try {
      const formattedData = {
        store_name: data.store_name,
        email: data.email,
        phone: data.phone,
        address: data.address,
        zip_code: data.zip_code,
        region_id: data.region_id,
        password: data.password,
        password_confirmation: data.password_confirmation,
        role: data.role,
        ein: data.ein,
      };

      const response = await register(formattedData).unwrap();
      if (response?.ok) {
        toast.success(response?.message || "Registration successful!");
        router.push(`/verify-otp?isregistared=true&email=${data.email}`);
      } else {
        toast.error(response?.message || "Registration failed!");
      }
    } catch (error: any) {
      toast.error(
        error?.data?.message || "Registration failed. Please try again."
      );
      console.error("Registration error:", error);
    }
  };

  return (
    <div className="flex w-full items-center justify-center !p-6 md:!p-10">
      <div className="w-full max-w-3xl">
        <div className={cn("flex flex-col gap-6", className)} {...props}>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">
                Register - Store
              </CardTitle>
              <CardDescription className="text-center">
                Enter your information to create your account.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="flex flex-col gap-6">
                  {/* Store Information */}
                  <div className="grid gap-2">
                    <Label htmlFor="store_name">Store Name</Label>
                    <Input
                      id="store_name"
                      type="text"
                      {...formRegister("store_name", {
                        required: "Store name is required",
                      })}
                    />
                    {errors.store_name && (
                      <span className="text-red-500 text-sm">
                        {errors.store_name.message}
                      </span>
                    )}
                  </div>

                  {/* Country and Region Selection */}
                  <div className="grid lg:grid-cols-2 grid-cols-1 gap-4 w-full">
                    <div className="grid gap-2 w-full">
                      <Label htmlFor="country">Country</Label>
                      <Select
                        onValueChange={handleCountryChange}
                        disabled={isLoadingCountries}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select country" />
                        </SelectTrigger>
                        <SelectContent>
                          {countriesResponse?.data?.map((country: Country) => (
                            <SelectItem
                              key={country.id}
                              value={country.id.toString()}
                            >
                              {country.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2 w-full">
                      <Label htmlFor="region">Region</Label>
                      <Select
                        onValueChange={(value) => setValue("region_id", value)}
                        disabled={!selectedCountryId || regions.length === 0}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue
                            placeholder={
                              regions.length
                                ? "Select region"
                                : "Select country first"
                            }
                          />
                        </SelectTrigger>
                        <SelectContent>
                          {regions.map((region) => (
                            <SelectItem
                              key={region.id}
                              value={region.id.toString()}
                            >
                              {region.name} ({region.code})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.region_id && (
                        <span className="text-red-500 text-sm">
                          Please select a region
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Address Information */}
                  <div className="grid gap-2">
                    <Label htmlFor="address">Current Address</Label>
                    <Input
                      id="address"
                      type="text"
                      {...formRegister("address", {
                        required: "Address is required",
                      })}
                    />
                    {errors.address && (
                      <span className="text-red-500 text-sm">
                        {errors.address.message}
                      </span>
                    )}
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="zip_code">Zip Code</Label>
                    <Input
                      id="zip_code"
                      type="text"
                      {...formRegister("zip_code")}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="ein">EIN</Label>
                    <Input
                      id="ein"
                      type="text"
                      {...formRegister("ein", {
                        required: "Store name is required",
                      })}
                    />
                    {errors.ein && (
                      <span className="text-red-500 text-sm">
                        {errors.ein.message}
                      </span>
                    )}
                  </div>

                  {/* Contact Information */}
                  <div className="grid gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="m@example.com"
                      {...formRegister("email", {
                        required: "Email is required",
                        pattern: {
                          value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                          message: "Invalid email address",
                        },
                      })}
                    />
                    {errors.email && (
                      <span className="text-red-500 text-sm">
                        {errors.email.message}
                      </span>
                    )}
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" type="tel" {...formRegister("phone")} />
                  </div>

                  {/* Password */}
                  <div className="grid gap-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      {...formRegister("password", {
                        required: "Password is required",
                        minLength: {
                          value: 8,
                          message: "Password must be at least 8 characters",
                        },
                      })}
                    />
                    {errors.password && (
                      <span className="text-red-500 text-sm">
                        {errors.password.message}
                      </span>
                    )}
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="password_confirmation">
                      Confirm Password
                    </Label>
                    <Input
                      id="password_confirmation"
                      type="password"
                      {...formRegister("password_confirmation", {
                        required: "Please confirm your password",
                        validate: (value) =>
                          value === watch("password") ||
                          "Passwords don't match",
                      })}
                    />
                    {errors.password_confirmation && (
                      <span className="text-red-500 text-sm">
                        {errors.password_confirmation.message}
                      </span>
                    )}
                  </div>
                  <div className="col-span-2 hidden gap-2">
                    <Label>Select Membership</Label>
                    <div className="w-full flex justify-between items-center gap-6">
                      <Select>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="FREE MEMBERSHIP" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="free">FREE MEMBERSHIP</SelectItem>
                          <SelectItem value="advocacy">
                            CASAA Advocacy Business Add‑On
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <MembershipInfo />
                    </div>
                  </div>

                  {/* Terms and Conditions */}
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="terms"
                      {...formRegister("terms", {
                        required: "You must accept the terms",
                      })}
                    />
                    <Label htmlFor="terms">
                      Accept{" "}
                      <button onClick={() => setIsModalOpen(true)}>
                        terms and conditions
                      </button>
                    </Label>
                  </div>
                  {errors.terms && (
                    <span className="text-red-500 text-sm">
                      {errors.terms.message}
                    </span>
                  )}

                  {/* Submit Button */}
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Creating account..." : "Create an account"}
                  </Button>
                </div>

                <div className="!mt-4 text-center text-sm">
                  Have an account?{" "}
                  <Link href="/login" className="underline underline-offset-4">
                    Login
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
      <TermsModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
