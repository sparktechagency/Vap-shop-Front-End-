"use client";
import TabsTriggerer from "./tabs-trigger";

export default function Page() {
  return (
    <main className="">
      <TabsTriggerer />
    </main>
  );
}
